# Peter Parquet
Quickly inspect parquet file in command line

# Where to get it
The source coid is currently hosted on Github at:
Binary installers for the latest version are available at the repo

```bash
pip install peter-parquet
```

# Usage
`peter-parquet --help` return all commands available

# Non Bash users
If you are a non Bash user, notice that Python package executables are installed to ~/.local/bin. So, make sure to add this entry to your PATH variable.

